---
name: Question
about: Ask a question about DataSovereign
title: "[Question]: "
labels: question, help wanted
assignees: ''

---

## Question

**What would you like to know about DataSovereign?**
A clear and concise description of your question.

## Context

**What are you trying to accomplish?**
Describe what you're working on or what you're trying to understand.

## What you've tried

**Have you checked the documentation?**
- [ ] I've read the README.md
- [ ] I've checked the DEPLOYMENT.md guide
- [ ] I've looked through existing issues
- [ ] I've searched the discussions

**What have you already tried?**
Describe any attempts you've made to find the answer.

## Environment (if relevant)

**What environment are you working with?**
- OS: [e.g. Windows, macOS, Linux]
- Browser: [e.g. Chrome, Firefox, Safari]
- Device: [e.g. Desktop, Mobile, Tablet]
- Version: [e.g. 1.0.0]

## Additional context

**Anything else that might help?**
Add any other context, screenshots, or information about your question here.

